# ==============================================================================
# Replication package -- 03_sem.R
#   Table 3   Recovered conditional cooperation (gamma) and lambda parameters
#   Table 4   Associations of trust and conflict with prior beliefs (delta)
#   Table S6  Full SEM coefficient estimates for compliance (beta)
#   Table S8  Cross-stage differences in gamma, lambda and beta (new; optional)
#   Figure S2 Sensitivity of lambda to round selection and aggregation window
#   Full parameter output (CSV) and a gamma/lambda coefficient plot
#
# Inference: cluster bootstrap resampling matching groups (cluster_var);
# Stage 1 and Stage 2 are re-estimated on the same resamples.
# ==============================================================================

if (!exists("setup_done")) source("00_setup.R")

# ------------------------------------------------------------------------------
# Main specification: final round of each stage (Round 8 within stage)
# ------------------------------------------------------------------------------
message("Main SEM: cluster bootstrap with ", B_sem, " replications ...")
sem_main <- run_sem_spec(8, 8, B = B_sem, seed = seed_main)
pe1 <- sem_main$pe1; pe2 <- sem_main$pe2
message("Usable replications: Stage 1 = ", attr(pe1, "n_ok"),
        ", Stage 2 = ", attr(pe2, "n_ok"), " of ", B_sem)

r2_1 <- lavInspect(sem_main$fit1, "rsquare"); r2_2 <- lavInspect(sem_main$fit2, "rsquare")
n_1  <- lavInspect(sem_main$fit1, "nobs");    n_2  <- lavInspect(sem_main$fit2, "nobs")

sem_note <- paste0(
  "Standard errors (in parentheses) from a cluster bootstrap with ", B_sem,
  " replications that resamples matching groups (", sem_main$boot$G,
  " clusters) with replacement; Stage 1 and Stage 2 are re-estimated on the same resamples. ",
  "p-values use the bootstrap standard error.")

# Full parameter output (all equations, both stages)
full_out <- bind_rows(pe1 %>% mutate(Stage = "Stage 1"), pe2 %>% mutate(Stage = "Stage 2")) %>%
  select(Stage, lhs, op, rhs, label, est, se, z, pvalue, ci.lower, ci.upper)
write.csv(full_out, file.path(path_out, "SEM_Round8_all_parameters.csv"), row.names = FALSE)

# ------------------------------------------------------------------------------
# Table 3: gamma and lambdas
# ------------------------------------------------------------------------------
table3 <- data.frame(
  Predictor = c("Conditional cooperation coefficient (γ)",
                "Information-weighted expectation parameters",
                "   Prior belief in-groups (λ₁)",
                "   Prior belief out-groups (λ₂)",
                "   Compliance in previous round (λ₃)",
                "Observations", "R²"),
  `Stage 1` = c(pe_cell(pe1, "gamma_cc", ":="), "",
                pe_cell(pe1, "lambda_union", ":="), pe_cell(pe1, "lambda_pm", ":="),
                pe_cell(pe1, "lambda_obs", ":="),
                as.character(n_1), sprintf("%.3f", r2_1["average_compliance_ini"])),
  `Stage 2` = c(pe_cell(pe2, "gamma_cc", ":="), "",
                pe_cell(pe2, "lambda_union", ":="), pe_cell(pe2, "lambda_pm", ":="),
                pe_cell(pe2, "lambda_obs", ":="),
                as.character(n_2), sprintf("%.3f", r2_2["average_compliance_ini"])),
  check.names = FALSE
)
export_table(table3, "Table_3_SEM_gamma_lambda",
             "Table 3 | Recovered conditional cooperation and information-weighted expectation parameters",
             notes = c("Estimates based on the final round of each stage (Rounds 8 and 16).",
                       sem_note, star_note))

# ------------------------------------------------------------------------------
# Table 4: belief equations (delta)
# ------------------------------------------------------------------------------
in_dv <- "belief_compliance_union"; out_dv <- "belief_compliance_pm"
table4 <- data.frame(
  Predictor = c("Trust in-groups (δ₁₂)", "Conflict in-groups (δ₁₃)",
                "Trust out-groups (δ₂₂)", "Conflict out-groups (δ₂₃)",
                "Constant (δ₁₁, δ₂₁)", "Num. obs.", "R²"),
  `Stage 1: In-groups` = c(pe_cell(pe1, in_dv, "~", "confianza_caleta"),
                           pe_cell(pe1, in_dv, "~", "conflicto_caleta"), "–", "–",
                           pe_cell(pe1, in_dv, "~1"), as.character(n_1), sprintf("%.3f", r2_1[in_dv])),
  `Stage 1: Out-groups` = c("–", "–", pe_cell(pe1, out_dv, "~", "confianza_pm"),
                            pe_cell(pe1, out_dv, "~", "conflicto_pm"),
                            pe_cell(pe1, out_dv, "~1"), as.character(n_1), sprintf("%.3f", r2_1[out_dv])),
  `Stage 2: In-groups` = c(pe_cell(pe2, in_dv, "~", "confianza_caleta"),
                           pe_cell(pe2, in_dv, "~", "conflicto_caleta"), "–", "–",
                           pe_cell(pe2, in_dv, "~1"), as.character(n_2), sprintf("%.3f", r2_2[in_dv])),
  `Stage 2: Out-groups` = c("–", "–", pe_cell(pe2, out_dv, "~", "confianza_metat"),
                            pe_cell(pe2, out_dv, "~", "conflicto_metat"),
                            pe_cell(pe2, out_dv, "~1"), as.character(n_2), sprintf("%.3f", r2_2[out_dv])),
  check.names = FALSE
)
export_table(table4, "Table_4_SEM_belief_equations",
             "Table 4 | Associations of trust and previous conflict with prior beliefs about compliance",
             notes = c(paste("Dependent variables: prior beliefs about in-group and out-group compliance,",
                             "rescaled to [0,1]. Trust and previous conflict are standardized."),
                       sem_note, star_note))

# ------------------------------------------------------------------------------
# Table S6: full compliance equation (beta)
# ------------------------------------------------------------------------------
cdv <- "average_compliance_ini"
s6_cells <- function(pe, trust_out, conflict_out) c(
  pe_cell(pe, cdv, "~", "belief_compliance_union"),
  pe_cell(pe, cdv, "~", "belief_compliance_pm"),
  pe_cell(pe, cdv, "~", "confianza_caleta"),
  pe_cell(pe, cdv, "~", "conflicto_caleta"),
  pe_cell(pe, cdv, "~", trust_out),
  pe_cell(pe, cdv, "~", conflict_out),
  pe_cell(pe, cdv, "~", "average_compliance_observed_ini_lag"),
  pe_cell(pe, cdv, "~1"))
tableS6 <- data.frame(
  Predictor = c("Prior belief, in-group (β₆)", "Prior belief, out-group (β₇)",
                "Trust, in-group (β₂)", "Previous conflict, in-group (β₃)",
                "Trust, out-group (β₄)", "Previous conflict, out-group (β₅)",
                "Observed compliance in preceding round (β₈)", "Constant (β₁)",
                "Observations", "R²"),
  `Stage 1: Unknown identity` = c(s6_cells(pe1, "confianza_pm", "conflicto_pm"),
                                  as.character(n_1), sprintf("%.3f", r2_1[cdv])),
  `Stage 2: Known identity`   = c(s6_cells(pe2, "confianza_metat", "conflicto_metat"),
                                  as.character(n_2), sprintf("%.3f", r2_2[cdv])),
  check.names = FALSE
)
export_table(tableS6, "Table_S6_SEM_full_compliance_equation",
             "Table S6 | Full SEM coefficient estimates for individual compliance in the CPR-Shared Area",
             notes = c(paste("Dependent variable: compliance in the final round of each stage (Rounds 8 and 16).",
                             "Observed compliance: other group members' mean compliance in the preceding round."),
                       sem_note, star_note))

# ------------------------------------------------------------------------------
# Table S8 (new): Stage 2 - Stage 1 differences, from the joint bootstrap
# ------------------------------------------------------------------------------
diff_keys <- c(
  "Conditional cooperation (γ)"            = "gamma_cc := c1+c2+c3",
  "Prior belief in-group (λ₁)"        = "lambda_union := c2/(c1+c2+c3)",
  "Prior belief out-group (λ₂)"       = "lambda_pm := c1/(c1+c2+c3)",
  "Observed compliance (λ₃)"          = "lambda_obs := c3/(c1+c2+c3)",
  "Prior belief in-group (β₆)"        = "average_compliance_ini ~ belief_compliance_union",
  "Prior belief out-group (β₇)"       = "average_compliance_ini ~ belief_compliance_pm",
  "Observed compliance (β₈)"          = "average_compliance_ini ~ average_compliance_observed_ini_lag"
)
bcols <- colnames(sem_main$boot$T1)
diff_keys[] <- vapply(diff_keys, function(k) bcols[gsub(" ", "", bcols) == gsub(" ", "", k)][1], "")
B1 <- sem_main$boot$T1[, diff_keys]; B2 <- sem_main$boot$T2[, diff_keys]
ok <- complete.cases(B1) & complete.cases(B2)
dmat <- B2[ok, , drop = FALSE] - B1[ok, , drop = FALSE]
e1 <- get_est(sem_main$fit1)[diff_keys]; e2 <- get_est(sem_main$fit2)[diff_keys]
d_se <- apply(dmat, 2, sd); d_p <- 2 * pnorm(-abs((e2 - e1) / d_se))
tableS8 <- data.frame(
  Parameter = names(diff_keys),
  `Stage 1` = sprintf("%.3f", e1), `Stage 2` = sprintf("%.3f", e2),
  `Difference (S2 − S1)` = fmt_coef(e2 - e1, d_se, d_p),
  `95% CI` = sprintf("[%.3f, %.3f]", apply(dmat, 2, quantile, 0.025), apply(dmat, 2, quantile, 0.975)),
  `p-value` = sprintf("%.3f", d_p),
  check.names = FALSE
)
export_table(tableS8, "Table_S8_SEM_stage_differences",
             "Table S8 | Differences in SEM parameters between identity-information conditions",
             notes = c(sem_note, "95% CIs are bootstrap percentile intervals.", star_note))

# ------------------------------------------------------------------------------
# Figure (not in manuscript): gamma and lambdas with percentile CIs
# ------------------------------------------------------------------------------
lam_labels <- c(lambda_union = "λ₁ Weight Beliefs In-group",
                lambda_pm    = "λ₂ Weight Beliefs Out-group",
                lambda_obs   = "λ₃ Weight Observed Comp.")
lam_cols <- c("#440154", "#2A788E", "#7AD151"); names(lam_cols) <- lam_labels

plot_main <- bind_rows(pe1 %>% mutate(Stage = "Stage 1"), pe2 %>% mutate(Stage = "Stage 2")) %>%
  filter(op == ":=") %>%
  mutate(Parameter = factor(c(gamma_cc = "Sum Conditional Cooperation (γ)", lam_labels)[lhs],
                            levels = rev(c("Sum Conditional Cooperation (γ)", lam_labels))))
p_main <- ggplot(plot_main, aes(est, Parameter, colour = Stage, shape = Stage)) +
  geom_vline(xintercept = 0, linetype = "dashed", colour = "gray50") +
  geom_errorbar(aes(xmin = ci.lower, xmax = ci.upper), orientation = "y", width = 0.2,
                position = position_dodge(width = 0.5), linewidth = 1) +
  geom_point(position = position_dodge(width = 0.5), size = 3.5) +
  scale_colour_manual(values = c("Stage 1" = "#3F4A8A", "Stage 2" = "#21908C")) +
  labs(x = "Estimate (95% cluster-bootstrap percentile CI)", y = NULL) +
  theme_minimal(base_size = 14) +
  theme(legend.position = "bottom", legend.title = element_blank(), panel.grid.minor = element_blank())
ggsave(file.path(path_out, "Figure_SEM_gamma_lambda.jpg"), p_main, width = 10, height = 6, dpi = 300)

# ------------------------------------------------------------------------------
# Figure S2: sensitivity to round selection and aggregation window
#   Single rounds 2-8 (round 1 has no lagged feedback) and windows [a, 8].
#   For a window [a, 8], compliance is averaged over rounds a..8 and observed
#   compliance is taken from round a-1 (as in the original estimation function).
# ------------------------------------------------------------------------------
specs <- c(lapply(2:8, function(r) list(start = r, end = r, label = paste("Round", r))),
           lapply(c(2, 5, 6, 7), function(a) list(start = a, end = 8,
                                                  label = sprintf("Mean rounds [%d,8]", a))))
sens <- bind_rows(lapply(seq_along(specs), function(i) {
  s <- specs[[i]]
  message("Figure S2: ", s$label)
  res <- if (s$start == 8 && s$end == 8) sem_main else
    run_sem_spec(s$start, s$end, B = B_sens, seed = seed_main + 100 + i)
  bind_rows(res$pe1 %>% mutate(Stage = "Shared Area (Stage 1)"),
            res$pe2 %>% mutate(Stage = "Shared Area (Stage 2)")) %>%
    filter(lhs %in% names(lam_labels)) %>%
    mutate(spec = s$label, n_boot_ok = c(attr(res$pe1, "n_ok"), attr(res$pe2, "n_ok"))[
      ifelse(Stage == "Shared Area (Stage 1)", 1, 2)])
}))
write.csv(sens %>% select(Stage, spec, lhs, est, se, pvalue, ci.lower, ci.upper, n_boot_ok),
          file.path(path_out, "Figure_S2_estimates.csv"), row.names = FALSE)

spec_levels <- c(paste("Round", 8:2), sprintf("Mean rounds [%d,8]", c(7, 6, 5, 2)))
plot_sens <- sens %>%
  mutate(spec = factor(spec, levels = spec_levels),
         Parameter = factor(lam_labels[lhs], levels = lam_labels),
         signif = ci.lower > 0 | ci.upper < 0)
avg_lines <- plot_sens %>% group_by(Stage, Parameter) %>% summarise(m = mean(est), .groups = "drop")

pd <- position_dodge(width = 0.6)
p_s2 <- ggplot(plot_sens, aes(est, spec, colour = Parameter, shape = Parameter, group = Parameter)) +
  geom_vline(xintercept = 0, colour = "gray70") +
  geom_vline(data = avg_lines, aes(xintercept = m, colour = Parameter), linetype = "dotted") +
  geom_errorbar(aes(xmin = ci.lower, xmax = ci.upper, alpha = signif), orientation = "y",
                width = 0, linewidth = 1, position = pd) +
  geom_point(aes(alpha = signif), size = 2.5, position = pd) +
  geom_text(data = filter(plot_sens, signif), aes(label = sprintf("%.2f", est)),
            position = pd, vjust = -0.8, size = 3, show.legend = FALSE) +
  scale_alpha_manual(values = c(`TRUE` = 1, `FALSE` = 0.3), guide = "none") +
  scale_colour_manual(values = lam_cols) +
  facet_wrap(~ Stage) +
  labs(x = "λ proportional weight (95% cluster-bootstrap percentile CI)",
       y = "Time period aggregation", colour = "Parameter", shape = "Parameter") +
  theme_minimal(base_size = 12) +
  theme(legend.position = "bottom", strip.text = element_text(face = "bold", size = 13),
        panel.grid.minor = element_blank())
ggsave(file.path(path_out, "Figure_S2_Lambda_sensitivity.jpg"), p_s2, width = 12, height = 12, dpi = 300)
message("Saved: Figure_S2_Lambda_sensitivity.jpg (faded = 95% CI includes 0; dotted = mean across specifications)")
