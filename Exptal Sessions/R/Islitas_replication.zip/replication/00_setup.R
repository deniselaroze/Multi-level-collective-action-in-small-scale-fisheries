# ==============================================================================
# Replication package -- 00_setup.R
# "Multi-level collective action in small-scale fisheries" (Islitas experiment)
#
# Loads packages, paths, settings, data and all helper functions used by
# 01_descriptives.R, 02_regressions.R and 03_sem.R. Every other script sources
# this file, so it is the only place where paths and settings are edited.
# ==============================================================================

# --- 1. Packages ----------------------------------------------------------------
pkgs <- c("dplyr", "tidyr", "lavaan", "lme4", "sandwich", "lmtest", "ggplot2")
missing_pkgs <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_pkgs) > 0) {
  stop("Please install: ", paste(missing_pkgs, collapse = ", "))
}
suppressPackageStartupMessages(invisible(lapply(pkgs, library, character.only = TRUE)))
# modelsummary (+ pandoc) is optional: used only to write .docx tables.
# Every table is always written as .csv as well.
has_modelsummary <- requireNamespace("modelsummary", quietly = TRUE)

# --- 2. Paths -------------------------------------------------------------------
path_github <- "C:/Users/DCCS2/Documents/GitHub/Multi-level-collective-action-in-small-scale-fisheries/Exptal Sessions/R/"
path_datos  <- "C:/Users/DCCS2/Dropbox/CICS/Experiments/Islitas/Data/Sessions"
path_out    <- file.path(path_github, "Outputs", "Replication")
dir.create(path_out, recursive = TRUE, showWarnings = FALSE)

# --- 3. Settings ----------------------------------------------------------------
cluster_var     <- "gid.treat"         # matching group: resampling / clustering unit
participant_var <- "participant.code"  # used for the participant-level comparison

B_sem  <- 1000   # cluster-bootstrap replications, main SEM (Tables 3, 4, S6, S8)
B_sens <- 1000   # cluster-bootstrap replications per specification, Figure S2
B_lmm  <- 2000   # cluster-bootstrap replications, mixed models (Table S7)
B_wcb  <- 9999   # wild cluster bootstrap replications (Tables 1, 2, S5)

# Stars in the OLS tables (Tables 1, 2, S5): "wcb" = wild cluster bootstrap
# p-values (recommended with few clusters); "cluster" = CR1 cluster-robust t-test.
stars_from <- "wcb"

seed_main <- 478

# quick_run = TRUE runs everything with few replications to check the pipeline
quick_run <- FALSE
if (quick_run) { B_sem <- 99; B_sens <- 99; B_lmm <- 99; B_wcb <- 999 }

# --- 4. Data --------------------------------------------------------------------
load(file.path(path_datos, "Datos_islitas_recode.Rdata"))  # wide data: df
load(file.path(path_datos, "Datos_islitas_long.Rdata"))    # long data: dfs_long
df_wide <- as.data.frame(df)
df_long <- as.data.frame(dfs_long)
rm(df, dfs_long)

# Checks on the clustering variable
for (nm in c("df_wide", "df_long")) {
  d <- get(nm)
  if (!cluster_var %in% names(d)) stop("'", cluster_var, "' not found in ", nm)
  if (anyNA(d[[cluster_var]]))    stop("'", cluster_var, "' has missing values in ", nm)
}
n_by_part <- tapply(df_long[[cluster_var]], df_long[[participant_var]],
                    function(x) length(unique(x)))
if (any(n_by_part > 1)) {
  warning("'", cluster_var, "' changes within participant in the long data. ",
          "Clustering assumes each participant belongs to one matching group.")
}
G_clusters <- length(unique(df_wide[[cluster_var]]))
message("Matching groups (", cluster_var, "): ", G_clusters,
        " | participants: ", nrow(df_wide))
if (G_clusters < 30) {
  message("Note: fewer than 30 clusters. Wild cluster bootstrap p-values are used ",
          "for OLS stars; bootstrap SEs for SEM/LMM should be read with caution.")
}

# --- 5. Formatting and export helpers ------------------------------------------
fmt_pct <- function(x, digits = 0) {
  ifelse(is.na(x), "\u2013", sprintf(paste0("%.", digits, "f%%"), x * 100))
}
fmt_msd <- function(x) {
  if (all(is.na(x))) return("\u2013")
  sprintf("%.2f (%.2f)", mean(x, na.rm = TRUE), sd(x, na.rm = TRUE))
}
stars <- function(p) {
  dplyr::case_when(is.na(p) ~ "", p < 0.001 ~ "***", p < 0.01 ~ "**",
                   p < 0.05 ~ "*", TRUE ~ "")
}
fmt_coef <- function(est, se, p, digits = 3) {
  sprintf(paste0("%.", digits, "f%s (%.", digits, "f)"), est, stars(p), se)
}
star_note <- "* p < 0.05, ** p < 0.01, *** p < 0.001."

export_table <- function(tab, name, title, notes = NULL) {
  write.csv(tab, file.path(path_out, paste0(name, ".csv")),
            row.names = FALSE, fileEncoding = "UTF-8")
  if (has_modelsummary) {
    tryCatch(
      modelsummary::datasummary_df(tab, title = title, notes = notes,
                                   output = file.path(path_out, paste0(name, ".docx"))),
      error = function(e) warning("Could not write ", name, ".docx: ", conditionMessage(e))
    )
  }
  message("Saved: ", name)
  invisible(tab)
}

# --- 6. OLS with clustered inference -------------------------------------------

# Wild cluster bootstrap (restricted, WCR) p-values with Webb six-point weights,
# for every coefficient of an OLS model (Cameron, Gelbach & Miller 2008;
# Webb 2023). Test statistic: CR1 cluster-robust t.
wild_cluster_p <- function(formula, data, cluster, B = 9999, seed = 1, chunk = 500) {
  X  <- model.matrix(formula, data)
  y  <- model.response(model.frame(formula, data))
  cl <- as.integer(factor(data[[cluster]]))
  G <- max(cl); N <- nrow(X); K <- ncol(X)
  adj  <- G / (G - 1) * (N - 1) / (N - K)
  XtXi <- solve(crossprod(X))
  b    <- drop(XtXi %*% crossprod(X, y))
  u    <- drop(y - X %*% b)
  se_k <- function(k, U) {             # CR1 SE of coefficient k for each column of U
    h <- drop(X %*% XtXi[k, ])
    sqrt(colSums(rowsum(h * U, cl)^2) * adj)
  }
  t0 <- vapply(seq_len(K), function(k) b[k] / se_k(k, matrix(u)), numeric(1))
  webb <- c(-sqrt(1.5), -1, -sqrt(0.5), sqrt(0.5), 1, sqrt(1.5))
  set.seed(seed)
  p <- numeric(K)
  for (k in seq_len(K)) {
    Xr <- X[, -k, drop = FALSE]
    fr <- if (ncol(Xr) == 0) rep(0, N) else drop(Xr %*% qr.coef(qr(Xr), y))
    ur <- y - fr
    exceed <- 0; done <- 0
    while (done < B) {
      nb <- min(chunk, B - done)
      W  <- matrix(sample(webb, G * nb, replace = TRUE), G, nb)
      Ys <- fr + ur * W[cl, , drop = FALSE]
      Bs <- XtXi %*% crossprod(X, Ys)
      Us <- Ys - X %*% Bs
      ts <- Bs[k, ] / se_k(k, Us)
      exceed <- exceed + sum(abs(ts) >= abs(t0[k]))
      done <- done + nb
    }
    p[k] <- exceed / B
  }
  setNames(p, colnames(X))
}

# Fits OLS and returns coefficients with:
#  - CR1 SEs clustered by matching group, t-test with G-1 df
#  - wild cluster bootstrap p-values (matching group)
#  - CR1 SEs clustered by participant (for comparison with earlier versions)
lm_cluster <- function(formula, data, cluster = cluster_var, alt_cluster = participant_var,
                       B = B_wcb, seed = seed_main) {
  vars <- intersect(unique(c(all.vars(formula), cluster, alt_cluster)), names(data))
  d <- data[complete.cases(data[, vars]), , drop = FALSE]
  m <- lm(formula, data = d)
  G <- length(unique(d[[cluster]]))
  V <- sandwich::vcovCL(m, cluster = d[[cluster]], type = "HC1")
  ct <- lmtest::coeftest(m, vcov. = V, df = G - 1)
  tab <- data.frame(term = rownames(ct), est = ct[, 1], se = ct[, 2],
                    p_cluster = ct[, 4], row.names = NULL)
  tab$p_wcb <- wild_cluster_p(formula, d, cluster, B = B, seed = seed)[tab$term]
  if (!is.null(alt_cluster) && alt_cluster %in% names(d)) {
    Va <- sandwich::vcovCL(m, cluster = d[[alt_cluster]], type = "HC1")
    ca <- lmtest::coeftest(m, vcov. = Va)
    tab$se_participant <- ca[, 2]
    tab$p_participant  <- ca[, 4]
  }
  tab$p_stars <- if (stars_from == "wcb") tab$p_wcb else tab$p_cluster
  F_rob <- if (ncol(model.matrix(m)) > 1) {
    lmtest::waldtest(m, vcov = V, test = "F")$F[2]
  } else NA_real_
  list(model = m, coefs = tab, G = G, F_robust = F_rob)
}

# Assembles a regression table from lm_cluster() results.
reg_table <- function(fits, coef_map, gof = c("nobs", "r2", "adj_r2")) {
  rows <- lapply(names(coef_map), function(term) {
    vals <- vapply(fits, function(f) {
      r <- f$coefs[f$coefs$term == term, ]
      if (nrow(r) == 0) "\u2013" else fmt_coef(r$est, r$se, r$p_stars)
    }, character(1))
    c(Predictor = unname(coef_map[term]), vals)
  })
  gof_rows <- list(
    nobs   = c(Predictor = "Num. obs.", vapply(fits, function(f) as.character(nobs(f$model)), "")),
    r2     = c(Predictor = "R\u00b2", vapply(fits, function(f) sprintf("%.3f", summary(f$model)$r.squared), "")),
    adj_r2 = c(Predictor = "Adjusted R\u00b2", vapply(fits, function(f) sprintf("%.3f", summary(f$model)$adj.r.squared), "")),
    F      = c(Predictor = "F statistic (cluster-robust)", vapply(fits, function(f) sprintf("%.3f", f$F_robust), "")),
    G      = c(Predictor = "Matching groups", vapply(fits, function(f) as.character(f$G), ""))
  )
  out <- as.data.frame(do.call(rbind, c(rows, gof_rows[gof])), stringsAsFactors = FALSE)
  names(out) <- c("Predictor", names(fits))
  out
}

# Long-format comparison of inference methods (for the robustness appendix)
inference_comparison <- function(fits) {
  dplyr::bind_rows(lapply(names(fits), function(nm) {
    cbind(model = nm, fits[[nm]]$coefs[, setdiff(names(fits[[nm]]$coefs), "p_stars")])
  }))
}

ols_note <- function() {
  paste0("Standard errors (in parentheses) are clustered by matching group (",
         G_clusters, " clusters; CR1). ",
         if (stars_from == "wcb") paste0("Significance is based on wild cluster bootstrap p-values (",
                                         B_wcb, " replications, Webb weights, null imposed). ")
         else "Significance is based on cluster-robust t-tests with G-1 degrees of freedom. ")
}

# --- 7. SEM helpers -------------------------------------------------------------
declare_get_columns <- function(prefix, suffix, start, end = NULL, data) {
  if (is.null(end)) end <- start
  unlist(lapply(start:end, function(r) {
    grep(paste0("^", prefix, "\\.", r, "\\.player\\.", suffix, "$"), names(data), value = TRUE)
  }))
}

# Stage 1 (unknown out-group). Compliance = mean over rounds R_start..R_end;
# observed compliance of others = round R_start - 1.
prep_T1 <- function(data, R_start, R_end) {
  cols <- declare_get_columns("T1juegoalgas", "T1_extraccion_libre", R_start, R_end, data)
  data$average_compliance_ini  <- 1 - rowMeans(data[, cols, drop = FALSE], na.rm = TRUE) / 50
  data$belief_compliance_pm    <- 1 - data$beliefsT1inicial.1.player.T1_belief_pm_en_libre_ini / 50
  data$belief_compliance_union <- 1 - data$beliefsT1inicial.1.player.T1_belief_caleta_en_libre_ini / 50
  data$confianza_caleta <- as.numeric(scale(data$survey1.1.player.confianza_caleta))
  data$conflicto_caleta <- as.numeric(scale(data$survey1.1.player.conflicto_caleta))
  data$confianza_pm     <- as.numeric(scale(data$survey1.1.player.confianza_pm))
  data$conflicto_pm     <- as.numeric(scale(data$survey1.1.player.conflicto_pm))
  cols_obs <- declare_get_columns("T1juegoalgas", "T1_extraccion_otros_libre", R_start - 1, R_start - 1, data)
  data$average_compliance_observed_ini_lag <- 1 - rowMeans(data[, cols_obs, drop = FALSE], na.rm = TRUE) / 150
  data
}

# Stage 2 (known out-group)
prep_T2 <- function(data, R_start, R_end) {
  cols <- declare_get_columns("T2juegoalgas", "T2_extraccion_metat", R_start, R_end, data)
  data$average_compliance_ini  <- 1 - rowMeans(data[, cols, drop = FALSE], na.rm = TRUE) / 50
  data$belief_compliance_pm    <- 1 - data$beliefsT2inicial.1.player.T2_belief_caleta_conocida_mean_ini / 50
  data$belief_compliance_union <- 1 - data$beliefsT2inicial.1.player.T2_belief_caleta_ini / 50
  data$confianza_caleta <- as.numeric(scale(data$survey1.1.player.confianza_caleta))
  data$conflicto_caleta <- as.numeric(scale(data$survey1.1.player.conflicto_caleta))
  data$confianza_metat  <- as.numeric(scale(data$survey2.1.player.confianza_caleta_conocida_mean))
  data$conflicto_metat  <- as.numeric(scale(data$survey2.1.player.conflicto_caleta_conocida_mean))
  cols_obs <- declare_get_columns("T2juegoalgas", "T2_extraccion_otros_metat", R_start - 1, R_start - 1, data)
  data$average_compliance_observed_ini_lag <- 1 - rowMeans(data[, cols_obs, drop = FALSE], na.rm = TRUE) / 150
  data
}

sem_syntax <- function(trust_out, conflict_out) {
  paste0('
    belief_compliance_pm ~ ', trust_out, ' + ', conflict_out, '
    belief_compliance_union ~ confianza_caleta + conflicto_caleta
    average_compliance_ini ~ c1*belief_compliance_pm + c2*belief_compliance_union + ',
         trust_out, ' + ', conflict_out, ' + confianza_caleta + conflicto_caleta + c3*average_compliance_observed_ini_lag
    belief_compliance_pm ~ 1
    belief_compliance_union ~ 1
    average_compliance_ini ~ 1
    gamma_cc     := c1 + c2 + c3
    lambda_pm    := c1 / (c1 + c2 + c3)
    lambda_union := c2 / (c1 + c2 + c3)
    lambda_obs   := c3 / (c1 + c2 + c3)
  ')
}
model_T1 <- sem_syntax("confianza_pm", "conflicto_pm")
model_T2 <- sem_syntax("confianza_metat", "conflicto_metat")

get_est <- function(fit) {
  pe <- parameterEstimates(fit, se = FALSE, zstat = FALSE, pvalue = FALSE, ci = FALSE)
  pe <- pe[pe$op %in% c("~", "~1", ":="), ]
  setNames(pe$est, paste(pe$lhs, pe$op, pe$rhs))
}

safe_est <- function(model, data, template) {
  out <- setNames(rep(NA_real_, length(template)), template)
  fit <- tryCatch(suppressWarnings(sem(model, data = data, estimator = "ML", se = "none")),
                  error = function(e) NULL)
  if (is.null(fit) || !isTRUE(lavInspect(fit, "converged"))) return(out)
  est <- get_est(fit)
  out[names(est)] <- est
  out
}

# Joint cluster bootstrap: the same resampled matching groups for both stages.
sem_cluster_boot <- function(d1, d2, fit1, fit2, B, seed, cluster = cluster_var) {
  rows_by_cl <- split(seq_len(nrow(d1)), d1[[cluster]])
  G <- length(rows_by_cl)
  tmpl1 <- names(get_est(fit1)); tmpl2 <- names(get_est(fit2))
  boot1 <- matrix(NA_real_, B, length(tmpl1), dimnames = list(NULL, tmpl1))
  boot2 <- matrix(NA_real_, B, length(tmpl2), dimnames = list(NULL, tmpl2))
  set.seed(seed)
  for (b in seq_len(B)) {
    idx <- unlist(rows_by_cl[sample(names(rows_by_cl), G, replace = TRUE)], use.names = FALSE)
    boot1[b, ] <- safe_est(model_T1, d1[idx, , drop = FALSE], tmpl1)
    boot2[b, ] <- safe_est(model_T2, d2[idx, , drop = FALSE], tmpl2)
  }
  list(T1 = boot1, T2 = boot2, G = G)
}

# Bootstrap SE, z-based p-value (est / bootstrap SE) and percentile 95% CI
summarise_boot <- function(fit, boot_mat) {
  pe <- parameterEstimates(fit, se = FALSE, zstat = FALSE, pvalue = FALSE, ci = FALSE)
  pe <- pe[pe$op %in% c("~", "~1", ":="), ]
  bm <- boot_mat[, paste(pe$lhs, pe$op, pe$rhs), drop = FALSE]
  bm <- bm[complete.cases(bm), , drop = FALSE]
  pe$se       <- apply(bm, 2, sd)
  pe$z        <- pe$est / pe$se
  pe$pvalue   <- 2 * pnorm(-abs(pe$z))
  pe$ci.lower <- apply(bm, 2, quantile, probs = 0.025, names = FALSE)
  pe$ci.upper <- apply(bm, 2, quantile, probs = 0.975, names = FALSE)
  attr(pe, "n_ok") <- nrow(bm)
  pe
}

# Runs the two-stage SEM for one outcome window, with the joint cluster bootstrap
run_sem_spec <- function(R_start, R_end, B, seed) {
  d1 <- prep_T1(df_wide, R_start, R_end)
  d2 <- prep_T2(df_wide, R_start, R_end)
  fit1 <- sem(model_T1, data = d1, estimator = "ML")
  fit2 <- sem(model_T2, data = d2, estimator = "ML")
  boot <- sem_cluster_boot(d1, d2, fit1, fit2, B = B, seed = seed)
  list(fit1 = fit1, fit2 = fit2, boot = boot,
       pe1 = summarise_boot(fit1, boot$T1), pe2 = summarise_boot(fit2, boot$T2))
}

# Formats one SEM parameter as "est*** (se)"
pe_cell <- function(pe, lhs, op, rhs = NULL) {
  keep <- pe$lhs == lhs & pe$op == op
  if (!is.null(rhs)) keep <- keep & pe$rhs %in% rhs
  r <- pe[keep, ]
  if (nrow(r) == 0) return("\u2013")
  fmt_coef(r$est[1], r$se[1], r$pvalue[1])
}

setup_done <- TRUE
