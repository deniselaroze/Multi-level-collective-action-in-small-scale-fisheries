# ==============================================================================
# Replication package -- 02_regressions.R
#   Table 2   Average compliance across areas and identity conditions (OLS)
#   Table S5  Predictors of changes in CPR-Shared Area compliance (OLS)
#   Table S7  Round-level mixed-effects models of compliance
# ==============================================================================

if (!exists("setup_done")) source("00_setup.R")

# ------------------------------------------------------------------------------
# Table 2: OLS on participant x stage x area average compliance
# ------------------------------------------------------------------------------
df_treatment <- df_long %>%
  mutate(compliance_TURF = 1 - extraction_amerb / 50,
         compliance_SA   = 1 - extraction_OA / 50) %>%
  group_by(.data[[participant_var]], .data[[cluster_var]], treatment) %>%
  summarise(avg_comp_TURF = mean(compliance_TURF, na.rm = TRUE),
            avg_comp_SA   = mean(compliance_SA, na.rm = TRUE), .groups = "drop") %>%
  pivot_longer(c(avg_comp_TURF, avg_comp_SA), names_to = "area", values_to = "mean_compliance") %>%
  mutate(stageTwo       = as.integer(treatment == "T2"),
         sharedArea     = as.integer(area == "avg_comp_SA"),
         knownOutGroups = stageTwo * sharedArea) %>%
  as.data.frame()

fit_t2 <- list(`Average compliance` =
  lm_cluster(mean_compliance ~ stageTwo + sharedArea + knownOutGroups, df_treatment,
             seed = seed_main + 2))

table2 <- reg_table(fit_t2, c(
  "(Intercept)"    = "Constant (α₀)",
  "stageTwo"       = "Stage 2 (α₁)",
  "sharedArea"     = "Shared Area (α₂)",
  "knownOutGroups" = "Shared Area × Stage 2 (α₃)"
), gof = c("nobs", "r2", "adj_r2", "G"))
export_table(table2, "Table_2_Average_compliance_OLS",
             "Table 2 | Average compliance across areas and identity conditions",
             notes = c(ols_note(), "The reference category is the TURF game in Stage 1.", star_note))
export_table(inference_comparison(fit_t2), "Table_2_inference_comparison",
             "Table 2: inference by matching group vs participant")

# ------------------------------------------------------------------------------
# Table S5: Changes in Shared Area compliance between stages (one row per participant)
# ------------------------------------------------------------------------------
T1_SA_cols <- paste0("T1juegoalgas.", 1:8, ".player.T1_extraccion_libre")
T2_SA_cols <- paste0("T2juegoalgas.", 1:8, ".player.T2_extraccion_metat")

df_models <- df_wide %>%
  mutate(
    comp_sa_T1   = 1 - rowMeans(df_wide[, T1_SA_cols], na.rm = TRUE) / 50,
    comp_sa_T2   = 1 - rowMeans(df_wide[, T2_SA_cols], na.rm = TRUE) / 50,
    diff_comp_sa = comp_sa_T2 - comp_sa_T1,
    diff_belief_in  = (1 - beliefsT2inicial.1.player.T2_belief_caleta_ini / 50) -
                      (1 - beliefsT1inicial.1.player.T1_belief_caleta_en_libre_ini / 50),
    diff_belief_out = (1 - beliefsT2inicial.1.player.T2_belief_caleta_conocida_mean_ini / 50) -
                      (1 - beliefsT1inicial.1.player.T1_belief_pm_en_libre_ini / 50),
    diff_trust_out    = survey2.1.player.confianza_caleta_conocida_mean - survey1.1.player.confianza_pm,
    diff_conflict_out = survey2.1.player.conflicto_caleta_conocida_mean - survey1.1.player.conflicto_pm
  )

fits_s5 <- list(
  `Model 1` = lm_cluster(diff_comp_sa ~ diff_belief_in + diff_belief_out, df_models,
                         alt_cluster = NULL, seed = seed_main + 3),
  `Model 2` = lm_cluster(diff_comp_sa ~ diff_trust_out + diff_conflict_out, df_models,
                         alt_cluster = NULL, seed = seed_main + 4),
  `Model 3` = lm_cluster(diff_comp_sa ~ diff_belief_in + diff_belief_out + diff_trust_out +
                           diff_conflict_out, df_models, alt_cluster = NULL, seed = seed_main + 5)
)
tableS5 <- reg_table(fits_s5, c(
  "(Intercept)"       = "Constant",
  "diff_belief_in"    = "Change in prior belief, in-group",
  "diff_belief_out"   = "Change in prior belief, out-group",
  "diff_trust_out"    = "Change in trust, out-group",
  "diff_conflict_out" = "Change in conflict, out-group"
), gof = c("nobs", "r2", "adj_r2", "F"))
export_table(tableS5, "Table_S5_Compliance_change_OLS",
             "Table S5 | Predictors of changes in CPR-Shared Area compliance",
             notes = c("OLS; one observation per participant (Stage 2 minus Stage 1).",
                       ols_note(), star_note))

# ------------------------------------------------------------------------------
# Table S7: Round-level mixed-effects models (participant random intercept),
#           cluster bootstrap by matching group
# ------------------------------------------------------------------------------
lmm_data <- df_long %>%
  transmute(pid = .data[[participant_var]], cl = .data[[cluster_var]],
            stageTwo = as.integer(treatment == "T2"),
            TURF = 1 - extraction_amerb / 50, SA = 1 - extraction_OA / 50) %>%
  pivot_longer(c(TURF, SA), names_to = "area", values_to = "compliance") %>%
  mutate(sharedArea = as.integer(area == "SA")) %>%
  filter(!is.na(compliance)) %>%
  as.data.frame()

lmm_forms <- list(
  `Model 1: Area difference` = compliance ~ sharedArea + (1 | pid),
  `Model 2: Area × stage` = compliance ~ sharedArea * stageTwo + (1 | pid)
)
lmm_ctrl <- lmerControl(calc.derivs = FALSE)
lmm_fits <- lapply(lmm_forms, function(f) lmer(f, data = lmm_data, control = lmm_ctrl))

# Resample matching groups; participants drawn more than once get new IDs so
# each copy has its own random intercept.
rows_by_cl <- split(seq_len(nrow(lmm_data)), lmm_data$cl)
lmm_boot <- lapply(lmm_fits, function(m) matrix(NA_real_, B_lmm, length(fixef(m)),
                                                 dimnames = list(NULL, names(fixef(m)))))
set.seed(seed_main + 6)
for (b in seq_len(B_lmm)) {
  draw <- sample(names(rows_by_cl), length(rows_by_cl), replace = TRUE)
  idx  <- rows_by_cl[draw]
  d    <- lmm_data[unlist(idx, use.names = FALSE), ]
  d$pid <- paste(rep(seq_along(idx), lengths(idx)), d$pid, sep = "_")
  for (k in names(lmm_forms)) {
    fit <- tryCatch(suppressMessages(suppressWarnings(lmer(lmm_forms[[k]], data = d, control = lmm_ctrl))),
                    error = function(e) NULL)
    if (!is.null(fit)) lmm_boot[[k]][b, ] <- fixef(fit)
  }
}

r2_nakagawa <- function(m) {
  vf <- var(drop(model.matrix(m) %*% fixef(m)))
  vr <- sum(vapply(VarCorr(m), function(v) v[1, 1], numeric(1)))
  ve <- sigma(m)^2
  c(marginal = vf / (vf + vr + ve), conditional = (vf + vr) / (vf + vr + ve))
}

s7_terms <- c("(Intercept)" = "Constant", "sharedArea" = "CPR-Shared Area",
              "stageTwo" = "Stage 2", "sharedArea:stageTwo" = "Shared Area × Stage 2")
s7_cols <- lapply(names(lmm_fits), function(k) {
  m <- lmm_fits[[k]]; bm <- lmm_boot[[k]][complete.cases(lmm_boot[[k]]), , drop = FALSE]
  est <- fixef(m); se <- apply(bm, 2, sd); p <- 2 * pnorm(-abs(est / se))
  cells <- vapply(names(s7_terms), function(t) {
    if (t %in% names(est)) fmt_coef(est[t], se[t], p[t]) else "–"
  }, character(1))
  r2 <- r2_nakagawa(m)
  c(cells, format(nobs(m), big.mark = ","), sprintf("%.3f", r2["marginal"]),
    sprintf("%.3f", r2["conditional"]), sprintf("%.3f", sqrt(mean(residuals(m)^2))),
    as.character(nrow(bm)))
})
tableS7 <- data.frame(
  Predictor = c(unname(s7_terms), "Observations", "Marginal R²", "Conditional R²",
                "RMSE", "Bootstrap replications used"),
  do.call(cbind, s7_cols), check.names = FALSE
)
names(tableS7)[-1] <- names(lmm_fits)
export_table(tableS7, "Table_S7_Mixed_effects",
             "Table S7 | Round-level mixed-effects models of compliance",
             notes = c(paste0("Linear mixed models with a participant random intercept (REML). ",
                              "Standard errors from a cluster bootstrap (", B_lmm,
                              " replications) resampling matching groups (", G_clusters,
                              " clusters); p-values use the bootstrap SE."), star_note))
