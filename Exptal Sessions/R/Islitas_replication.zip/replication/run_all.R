# ==============================================================================
# Replication package -- run_all.R
# Runs every analysis in the manuscript and writes all tables (.csv, and .docx
# when modelsummary + pandoc are available) and figures to path_out.
#
# Set the working directory to this folder first, e.g. in RStudio:
#   Session > Set Working Directory > To Source File Location
# Edit paths and settings in 00_setup.R.
# ==============================================================================

rm(list = ls())
t0 <- Sys.time()

source("00_setup.R")
source("01_descriptives.R")   # Table 1, Tables S1, S2, S4
source("02_regressions.R")    # Table 2, Tables S5, S7
source("03_sem.R")            # Tables 3, 4, S6, S8, Figure S2

writeLines(capture.output(sessionInfo()), file.path(path_out, "sessionInfo.txt"))
message("\nDone in ", round(difftime(Sys.time(), t0, units = "mins"), 1),
        " minutes. Outputs in: ", path_out)
